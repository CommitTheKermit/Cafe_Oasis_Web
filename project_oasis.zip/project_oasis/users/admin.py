from django.contrib import admin
from .models import User, UserKeywords

admin.site.register(User)
admin.site.register(UserKeywords)
# Register your models here.
