from django.contrib import admin
from .models import Cafe, CafeKeywords

# Register your models here.
admin.site.register(Cafe)
admin.site.register(CafeKeywords)
